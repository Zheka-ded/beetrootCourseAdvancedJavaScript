export default [
  { name: "Tim", status: "active" },
  { name: "Bob", status: "pending" },
  { name: "Joe", status: "active" },
  { name: "Ashley", status: "active" },
  { name: "Jim", status: "inactive" },
  { name: "Paul", status: "inactive" }
];
