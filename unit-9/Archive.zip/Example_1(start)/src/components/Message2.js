import React from "react";

const Message2 = () => <p>Hello User</p>;

export default Message2;
