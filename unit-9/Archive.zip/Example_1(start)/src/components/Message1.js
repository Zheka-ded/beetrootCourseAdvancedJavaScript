import React from "react";

const Message1 = () => <p>Hello Admin</p>;

export default Message1;
